// Data storage (using localStorage for simplicity, in production use a backend)
let users = JSON.parse(localStorage.getItem('users')) || [];
let employees = JSON.parse(localStorage.getItem('employees')) || [];
let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
let leaves = JSON.parse(localStorage.getItem('leaves')) || [];
let candidates = JSON.parse(localStorage.getItem('candidates')) || [];
let reviews = JSON.parse(localStorage.getItem('reviews')) || [];
let trainings = JSON.parse(localStorage.getItem('trainings')) || [];

let currentUser = JSON.parse(localStorage.getItem('currentUser')) || null;

// Check if user is logged in, if not redirect to login
if (!currentUser) {
    window.location.href = 'login.html';
}

// DOM elements
const app = document.getElementById('app');

// Logout
document.getElementById('logout-btn').addEventListener('click', function() {
    localStorage.removeItem('currentUser');
    window.location.href = 'login.html';
});

// Tab navigation
document.getElementById('employees-tab').addEventListener('click', () => showSection('employees'));
document.getElementById('tasks-tab').addEventListener('click', () => showSection('tasks'));
document.getElementById('leaves-tab').addEventListener('click', () => showSection('leaves'));
document.getElementById('hiring-tab').addEventListener('click', () => showSection('hiring'));
document.getElementById('performance-tab').addEventListener('click', () => showSection('performance'));
document.getElementById('training-tab').addEventListener('click', () => showSection('training'));
document.getElementById('reports-tab').addEventListener('click', () => showSection('reports'));

// Employee management
document.getElementById('add-employee-btn').addEventListener('click', () => showModal('employee-modal'));
document.getElementById('employee-form').addEventListener('submit', saveEmployee);
document.getElementById('search-employee').addEventListener('input', filterEmployees);

// Task management
document.getElementById('add-task-btn').addEventListener('click', () => showModal('task-modal'));
document.getElementById('task-form').addEventListener('submit', saveTask);
document.getElementById('search-task').addEventListener('input', filterTasks);

// Leave management
document.getElementById('apply-leave-btn').addEventListener('click', () => showModal('leave-modal'));
document.getElementById('leave-form').addEventListener('submit', saveLeave);
document.getElementById('search-leave').addEventListener('input', filterLeaves);

// Hiring management
document.getElementById('add-candidate-btn').addEventListener('click', () => showModal('candidate-modal'));
document.getElementById('candidate-form').addEventListener('submit', saveCandidate);
document.getElementById('search-candidate').addEventListener('input', filterCandidates);

// Performance management
document.getElementById('add-review-btn').addEventListener('click', () => showModal('review-modal'));
document.getElementById('review-form').addEventListener('submit', saveReview);
document.getElementById('search-review').addEventListener('input', filterReviews);

// Training management
document.getElementById('add-training-btn').addEventListener('click', () => showModal('training-modal'));
document.getElementById('training-form').addEventListener('submit', saveTraining);
document.getElementById('search-training').addEventListener('input', filterTrainings);

// Reports
document.getElementById('generate-attendance-report').addEventListener('click', generateAttendanceReport);
document.getElementById('generate-leaves-report').addEventListener('click', generateLeavesReport);
document.getElementById('generate-performance-report').addEventListener('click', generatePerformanceReport);
document.getElementById('backup-data').addEventListener('click', backupData);
document.getElementById('restore-data').addEventListener('click', () => document.getElementById('restore-file').click());
document.getElementById('restore-file').addEventListener('change', restoreData);

// Modal close
document.querySelectorAll('.close').forEach(close => close.addEventListener('click', () => hideModal()));

// Initialize app
showSection('employees');
loadEmployees();
loadTasks();
loadLeaves();
loadCandidates();
loadReviews();
loadTrainings();

// Functions
function showSection(section) {
    document.querySelectorAll('.section').forEach(s => s.classList.add('hidden'));
    document.getElementById(section + '-section').classList.remove('hidden');
    document.querySelectorAll('nav button').forEach(btn => btn.classList.remove('active'));
    document.getElementById(section + '-tab').classList.add('active');
}

function showModal(modalId) {
    document.getElementById(modalId).classList.remove('hidden');
}

function hideModal() {
    document.querySelectorAll('.modal').forEach(modal => modal.classList.add('hidden'));
}

function saveEmployee(e) {
    e.preventDefault();
    const name = document.getElementById('emp-name').value;
    const id = document.getElementById('emp-id').value;
    const dept = document.getElementById('emp-dept').value;
    const contact = document.getElementById('emp-contact').value;
    const role = document.getElementById('emp-role').value;
    employees.push({ name, id, dept, contact, role });
    localStorage.setItem('employees', JSON.stringify(employees));
    loadEmployees();
    hideModal();
    document.getElementById('employee-form').reset();
}

function loadEmployees() {
    const tbody = document.querySelector('#employees-table tbody');
    tbody.innerHTML = '';
    employees.forEach((emp, index) => {
        const row = tbody.insertRow();
        row.insertCell().textContent = emp.id;
        row.insertCell().textContent = emp.name;
        row.insertCell().textContent = emp.dept;
        row.insertCell().textContent = emp.contact;
        row.insertCell().textContent = emp.role;
        const actions = row.insertCell();
        actions.innerHTML = `<button onclick="editEmployee(${index})">Edit</button> <button onclick="deleteEmployee(${index})">Delete</button>`;
    });
}

function editEmployee(index) {
    const emp = employees[index];
    document.getElementById('emp-name').value = emp.name;
    document.getElementById('emp-id').value = emp.id;
    document.getElementById('emp-dept').value = emp.dept;
    document.getElementById('emp-contact').value = emp.contact;
    document.getElementById('emp-role').value = emp.role;
    showModal('employee-modal');
    document.getElementById('employee-form').onsubmit = function(e) {
        e.preventDefault();
        emp.name = document.getElementById('emp-name').value;
        emp.id = document.getElementById('emp-id').value;
        emp.dept = document.getElementById('emp-dept').value;
        emp.contact = document.getElementById('emp-contact').value;
        emp.role = document.getElementById('emp-role').value;
        localStorage.setItem('employees', JSON.stringify(employees));
        loadEmployees();
        hideModal();
        document.getElementById('employee-form').reset();
        document.getElementById('employee-form').onsubmit = saveEmployee;
    };
}

function deleteEmployee(index) {
    employees.splice(index, 1);
    localStorage.setItem('employees', JSON.stringify(employees));
    loadEmployees();
}

function filterEmployees() {
    const search = document.getElementById('search-employee').value.toLowerCase();
    const rows = document.querySelectorAll('#employees-table tbody tr');
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(search) ? '' : 'none';
    });
}

function saveTask(e) {
    e.preventDefault();
    const title = document.getElementById('task-title').value;
    const desc = document.getElementById('task-desc').value;
    const deadline = document.getElementById('task-deadline').value;
    tasks.push({ title, desc, deadline, status: 'Open' });
    localStorage.setItem('tasks', JSON.stringify(tasks));
    loadTasks();
    hideModal();
    document.getElementById('task-form').reset();
}

function loadTasks() {
    const tbody = document.querySelector('#tasks-table tbody');
    tbody.innerHTML = '';
    tasks.forEach((task, index) => {
        const row = tbody.insertRow();
        row.insertCell().textContent = task.title;
        row.insertCell().textContent = task.desc;
        row.insertCell().textContent = task.deadline;
        row.insertCell().textContent = task.status;
        const actions = row.insertCell();
        actions.innerHTML = `<button onclick="updateTaskStatus(${index})">${task.status === 'Open' ? 'Close' : 'Open'}</button> <button onclick="deleteTask(${index})">Delete</button>`;
    });
}

function updateTaskStatus(index) {
    tasks[index].status = tasks[index].status === 'Open' ? 'Closed' : 'Open';
    localStorage.setItem('tasks', JSON.stringify(tasks));
    loadTasks();
}

function deleteTask(index) {
    tasks.splice(index, 1);
    localStorage.setItem('tasks', JSON.stringify(tasks));
    loadTasks();
}

function filterTasks() {
    const search = document.getElementById('search-task').value.toLowerCase();
    const rows = document.querySelectorAll('#tasks-table tbody tr');
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(search) ? '' : 'none';
    });
}

function saveLeave(e) {
    e.preventDefault();
    const start = document.getElementById('leave-start').value;
    const end = document.getElementById('leave-end').value;
    const reason = document.getElementById('leave-reason').value;
    leaves.push({ employee: currentUser.username, start, end, reason, status: 'Pending' });
    localStorage.setItem('leaves', JSON.stringify(leaves));
    loadLeaves();
    hideModal();
    document.getElementById('leave-form').reset();
}

function loadLeaves() {
    const tbody = document.querySelector('#leaves-table tbody');
    tbody.innerHTML = '';
    leaves.forEach((leave, index) => {
        const row = tbody.insertRow();
        row.insertCell().textContent = leave.employee;
        row.insertCell().textContent = leave.start;
        row.insertCell().textContent = leave.end;
        row.insertCell().textContent = leave.reason;
        row.insertCell().textContent = leave.status;
        const actions = row.insertCell();
        if (currentUser.role === 'hr') {
            actions.innerHTML = `<button onclick="approveLeave(${index})">Approve</button> <button onclick="rejectLeave(${index})">Reject</button>`;
        } else {
            actions.innerHTML = 'N/A';
        }
    });
}

function approveLeave(index) {
    leaves[index].status = 'Approved';
    localStorage.setItem('leaves', JSON.stringify(leaves));
    loadLeaves();
}

function rejectLeave(index) {
    leaves[index].status = 'Rejected';
    localStorage.setItem('leaves', JSON.stringify(leaves));
    loadLeaves();
}

function filterLeaves() {
    const search = document.getElementById('search-leave').value.toLowerCase();
    const rows = document.querySelectorAll('#leaves-table tbody tr');
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(search) ? '' : 'none';
    });
}

function saveCandidate(e) {
    e.preventDefault();
    const name = document.getElementById('cand-name').value;
    const position = document.getElementById('cand-position').value;
    const interview = document.getElementById('cand-interview').value;
    candidates.push({ name, position, status: 'Applied', interview });
    localStorage.setItem('candidates', JSON.stringify(candidates));
    loadCandidates();
    hideModal();
    document.getElementById('candidate-form').reset();
}

function loadCandidates() {
    const tbody = document.querySelector('#candidates-table tbody');
    tbody.innerHTML = '';
    candidates.forEach((cand, index) => {
        const row = tbody.insertRow();
        row.insertCell().textContent = cand.name;
        row.insertCell().textContent = cand.position;
        row.insertCell().textContent = cand.status;
        row.insertCell().textContent = cand.interview;
        const actions = row.insertCell();
        actions.innerHTML = `<button onclick="updateCandidateStatus(${index})">Update Status</button> <button onclick="deleteCandidate(${index})">Delete</button>`;
    });
}

function updateCandidateStatus(index) {
    const status = prompt('Enter new status:');
    if (status) {
        candidates[index].status = status;
        localStorage.setItem('candidates', JSON.stringify(candidates));
        loadCandidates();
    }
}

function deleteCandidate(index) {
    candidates.splice(index, 1);
    localStorage.setItem('candidates', JSON.stringify(candidates));
    loadCandidates();
}

function filterCandidates() {
    const search = document.getElementById('search-candidate').value.toLowerCase();
    const rows = document.querySelectorAll('#candidates-table tbody tr');
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(search) ? '' : 'none';
    });
}

function saveReview(e) {
    e.preventDefault();
    const emp = document.getElementById('review-emp').value;
    const rating = document.getElementById('review-rating').value;
    const remarks = document.getElementById('review-remarks').value;
    reviews.push({ employee: emp, rating, remarks, date: new Date().toISOString().split('T')[0] });
    localStorage.setItem('reviews', JSON.stringify(reviews));
    loadReviews();
    hideModal();
    document.getElementById('review-form').reset();
}

function loadReviews() {
    const tbody = document.querySelector('#reviews-table tbody');
    tbody.innerHTML = '';
    reviews.forEach((review, index) => {
        const row = tbody.insertRow();
        row.insertCell().textContent = review.employee;
        row.insertCell().textContent = review.rating;
        row.insertCell().textContent = review.remarks;
        row.insertCell().textContent = review.date;
        const actions = row.insertCell();
        actions.innerHTML = `<button onclick="deleteReview(${index})">Delete</button>`;
    });
    // Populate employee select
    const select = document.getElementById('review-emp');
    select.innerHTML = '<option value="">Select Employee</option>';
    employees.forEach(emp => {
        select.innerHTML += `<option value="${emp.name}">${emp.name}</option>`;
    });
}

function deleteReview(index) {
    reviews.splice(index, 1);
    localStorage.setItem('reviews', JSON.stringify(reviews));
    loadReviews();
}

function filterReviews() {
    const search = document.getElementById('search-review').value.toLowerCase();
    const rows = document.querySelectorAll('#reviews-table tbody tr');
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(search) ? '' : 'none';
    });
}

function saveTraining(e) {
    e.preventDefault();
    const title = document.getElementById('training-title').value;
    const desc = document.getElementById('training-desc').value;
    const assigned = document.getElementById('training-assigned').value;
    trainings.push({ title, desc, assigned, completion: 'Not Completed' });
    localStorage.setItem('trainings', JSON.stringify(trainings));
    loadTrainings();
    hideModal();
    document.getElementById('training-form').reset();
}

function loadTrainings() {
    const tbody = document.querySelector('#training-table tbody');
    tbody.innerHTML = '';
    trainings.forEach((training, index) => {
        const row = tbody.insertRow();
        row.insertCell().textContent = training.title;
        row.insertCell().textContent = training.desc;
        row.insertCell().textContent = training.assigned;
        row.insertCell().textContent = training.completion;
        const actions = row.insertCell();
        actions.innerHTML = `<button onclick="updateTrainingCompletion(${index})">${training.completion === 'Not Completed' ? 'Mark Complete' : 'Mark Incomplete'}</button> <button onclick="deleteTraining(${index})">Delete</button>`;
    });
    // Populate employee select
    const select = document.getElementById('training-assigned');
    select.innerHTML = '<option value="">Select Employee</option>';
    employees.forEach(emp => {
        select.innerHTML += `<option value="${emp.name}">${emp.name}</option>`;
    });
}

function updateTrainingCompletion(index) {
    trainings[index].completion = trainings[index].completion === 'Not Completed' ? 'Completed' : 'Not Completed';
    localStorage.setItem('trainings', JSON.stringify(trainings));
    loadTrainings();
}

function deleteTraining(index) {
    trainings.splice(index, 1);
    localStorage.setItem('trainings', JSON.stringify(trainings));
    loadTrainings();
}

function filterTrainings() {
    const search = document.getElementById('search-training').value.toLowerCase();
    const rows = document.querySelectorAll('#training-table tbody tr');
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(search) ? '' : 'none';
    });
}

function generateAttendanceReport() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    doc.text('Attendance Report', 10, 10);
    doc.text('Generated on: ' + new Date().toLocaleDateString(), 10, 20);
    doc.text('Employees:', 10, 30);
    let y = 40;
    employees.forEach(emp => {
        doc.text(`${emp.name} (${emp.id}) - Department: ${emp.dept}`, 10, y);
        y += 10;
    });
    doc.save('attendance_report.pdf');
}

function generateLeavesReport() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    doc.text('Leaves Report', 10, 10);
    doc.text('Generated on: ' + new Date().toLocaleDateString(), 10, 20);
    doc.text('Leave Requests:', 10, 30);
    let y = 40;
    leaves.forEach(leave => {
        doc.text(`${leave.employee}: ${leave.start} to ${leave.end} - ${leave.status}`, 10, y);
        y += 10;
    });
    doc.save('leaves_report.pdf');
}

function generatePerformanceReport() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    doc.text('Performance Report', 10, 10);
    doc.text('Generated on: ' + new Date().toLocaleDateString(), 10, 20);
    doc.text('Reviews:', 10, 30);
    let y = 40;
    reviews.forEach(review => {
        doc.text(`${review.employee}: Rating ${review.rating} - ${review.remarks}`, 10, y);
        y += 10;
    });
    doc.save('performance_report.pdf');
}

function backupData() {
    const data = {
        users,
        employees,
        tasks,
        leaves,
        candidates,
        reviews,
        trainings
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'hr_planner_backup.json';
    a.click();
    URL.revokeObjectURL(url);
}

function restoreData(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            try {
                const data = JSON.parse(e.target.result);
                users = data.users || [];
                employees = data.employees || [];
                tasks = data.tasks || [];
                leaves = data.leaves || [];
                candidates = data.candidates || [];
                reviews = data.reviews || [];
                trainings = data.trainings || [];
                localStorage.setItem('users', JSON.stringify(users));
                localStorage.setItem('employees', JSON.stringify(employees));
                localStorage.setItem('tasks', JSON.stringify(tasks));
                localStorage.setItem('leaves', JSON.stringify(leaves));
                localStorage.setItem('candidates', JSON.stringify(candidates));
                localStorage.setItem('reviews', JSON.stringify(reviews));
                localStorage.setItem('trainings', JSON.stringify(trainings));
                loadEmployees();
                loadTasks();
                loadLeaves();
                loadCandidates();
                loadReviews();
                loadTrainings();
                alert('Data restored successfully');
            } catch (error) {
                alert('Invalid backup file');
            }
        };
        reader.readAsText(file);
    }
}
