// Data storage (using localStorage for simplicity, in production use a backend)
let users = JSON.parse(localStorage.getItem('users')) || [];

// DOM elements
const loginContainer = document.getElementById('login-container');
const registerContainer = document.getElementById('register-container');
const resetContainer = document.getElementById('reset-container');

// Event listeners for navigation
document.getElementById('register-btn').addEventListener('click', showRegister);
document.getElementById('reset-password-btn').addEventListener('click', showReset);
document.getElementById('back-to-login').addEventListener('click', showLogin);
document.getElementById('back-to-login-reset').addEventListener('click', showLogin);

// Login form
document.getElementById('login-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
        localStorage.setItem('currentUser', JSON.stringify(user));
        window.location.href = 'index.html';
    } else {
        document.getElementById('login-error').textContent = 'Invalid credentials';
    }
});

// Register form
document.getElementById('register-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const username = document.getElementById('reg-username').value;
    const password = document.getElementById('reg-password').value;
    const role = document.getElementById('reg-role').value;
    if (users.find(u => u.username === username)) {
        alert('Username already exists');
        return;
    }
    users.push({ username, password, role });
    localStorage.setItem('users', JSON.stringify(users));
    alert('Registration successful');
    showLogin();
});

// Reset password form
document.getElementById('reset-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const username = document.getElementById('reset-username').value;
    const newPassword = document.getElementById('new-password').value;
    const user = users.find(u => u.username === username);
    if (user) {
        user.password = newPassword;
        localStorage.setItem('users', JSON.stringify(users));
        alert('Password reset successful');
        showLogin();
    } else {
        alert('User not found');
    }
});

// Functions
function showLogin() {
    loginContainer.classList.remove('hidden');
    registerContainer.classList.add('hidden');
    resetContainer.classList.add('hidden');
}

function showRegister() {
    loginContainer.classList.add('hidden');
    registerContainer.classList.remove('hidden');
    resetContainer.classList.add('hidden');
}

function showReset() {
    loginContainer.classList.add('hidden');
    registerContainer.classList.add('hidden');
    resetContainer.classList.remove('hidden');
}
